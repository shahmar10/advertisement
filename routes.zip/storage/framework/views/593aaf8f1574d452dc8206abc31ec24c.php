<?php $__env->startSection('content'); ?>

    <div class="container-fluid">

        <div class="row">
            <div class="col-md-10">
                <h1 class="h3 mb-2 text-gray-800">Advertisement</h1>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                Featured
            </div>
            <ul class="list-group list-group-flush">
                <li class="list-group-item">About : <?php echo e($advertisement->body); ?></li>
                <li class="list-group-item">Applier : <?php echo e($advertisement->creator); ?></li>
                <li class="list-group-item">Car : <?php echo e($advertisement->car); ?></li>
                <li class="list-group-item">Model : <?php echo e($advertisement->model); ?></li>
                <li class="list-group-item">Price : <?php echo e($advertisement->price); ?></li>
                <li class="list-group-item">Currency : <?php echo e($advertisement->currency); ?></li>
                <li class="list-group-item">Created at : <?php echo e($advertisement->created_at); ?></li>
                <li class="list-group-item">Fuel type : <?php echo e($advertisement->fuel_type); ?></li>
                <li class="list-group-item">Year : <?php echo e($advertisement->year); ?></li>
                <li class="list-group-item">Color : <?php echo e($advertisement->color); ?></li>
                <li class="list-group-item">Distance : <?php echo e($advertisement->distance); ?></li>
                <li class="list-group-item">Vin code : <?php echo e($advertisement->vin_code); ?></li>
                <li class="list-group-item">City : <?php echo e($advertisement->city); ?></li>
                <li class="list-group-item">
                    Suppliers :
                    <?php $__currentLoopData = $advertisement->suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($supplier->name); ?>


                        <?php if($loop->iteration != count($advertisement->suppliers)): ?>
                            ,
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </li>
                <li class="list-group-item">
                    <?php $__currentLoopData = $advertisement->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <img src="<?php echo e($photo->photo); ?>" alt="" width="300px">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </li>
            </ul>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.core.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\coders\php\advertisement\resources\views/dashboard/advertisement/show.blade.php ENDPATH**/ ?>