<?php echo $body; ?>

<?php /**PATH C:\laragon\www\coders\php\advertisement\resources\views/mail/standart.blade.php ENDPATH**/ ?>