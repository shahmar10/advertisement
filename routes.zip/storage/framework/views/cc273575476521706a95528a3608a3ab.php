<?php $__env->startSection('content'); ?>
    <main>
        <section class="announcement px-4 py-2">
            <div class="row mt-4">
                <div class="col-12 col-md-8">
                    <div>
                        <div class="autoinfoName">
                            <?php echo e($advertisement->car . ' ' . $advertisement->model . ' , ' . $advertisement->year . ' , ' . $advertisement->distance); ?>

                        </div>

                        <div class="f-carousel" id="myCarousel">
                            <?php $__currentLoopData = $advertisement->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="f-carousel__slide "
                                     data-thumb-src="<?php echo e($photo->photo); ?>">
                                    <a href="" data-fancybox="gallery"
                                       data-src="<?php echo e($photo->photo); ?>"
                                       data-caption="Caption #1">
                                        <img src="<?php echo e($photo->photo); ?>"/>
                                    </a>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <div>
                            <span> Yeniləndi: <?php echo e($advertisement->updated_at); ?></span>
                            <span cla>Baxışların sayı: <?php echo e($advertisement->view); ?></span>
                        </div>
                        <hr/>

                        <div class="row mt-3">
                            <div class="col-md-6">
                                <div class="infoAutoAbout">
                                    <div class="infoAutoAboutKey">Şəhər</div>
                                    <div class="infoAutoAboutData"><?php echo e($advertisement->city); ?></div>
                                </div>
                                <div class="infoAutoAbout">
                                    <div class="infoAutoAboutKey">Marka</div>
                                    <div class="infoAutoAboutData"><?php echo e($advertisement->car); ?></div>
                                </div>
                                <div class="infoAutoAbout">
                                    <div class="infoAutoAboutKey">Model</div>
                                    <div class="infoAutoAboutData"><?php echo e($advertisement->model); ?></div>
                                </div>
                                <div class="infoAutoAbout">
                                    <div class="infoAutoAboutKey">Buraxılış ili</div>
                                    <div class="infoAutoAboutData"><?php echo e($advertisement->year); ?></div>
                                </div>
                                <div class="infoAutoAbout">
                                    <div class="infoAutoAboutKey">Ban növü</div>
                                    <div class="infoAutoAboutData">
                                        <?php echo e($advertisement->ban); ?>

                                    </div>
                                </div>
                                <div class="infoAutoAbout">
                                    <div class="infoAutoAboutKey">Rəng</div>
                                    <div class="infoAutoAboutData"><?php echo e($advertisement->color); ?></div>
                                </div>
                                <div class="infoAutoAbout">
                                    <div class="infoAutoAboutKey">Benzin</div>
                                    <div class="infoAutoAboutData"><?php echo e($advertisement->fuel_type); ?></div>
                                </div>
                                <div class="infoAutoAbout">
                                    <div class="infoAutoAboutKey">Yürüş</div>
                                    <div class="infoAutoAboutData"><?php echo e($advertisement->distance); ?></div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="infoAutoAbout">
                                    <div class="infoAutoAboutKey">Sürətlər qutusu</div>
                                    <div class="infoAutoAboutData">Avtomat</div>
                                </div>
                                <div class="infoAutoAbout">
                                    <div class="infoAutoAboutKey">Ötürücü</div>
                                    <div class="infoAutoAboutData"><?php echo e($advertisement->gear); ?></div>
                                </div>
                                <div class="infoAutoAbout">
                                    <div class="infoAutoAboutKey">
                                        Hansı bazar üçün yığılıb
                                    </div>
                                    <div class="infoAutoAboutData">Amerika</div>
                                </div>
                            </div>
                        </div>

                        <br>

                        <div class="">
                            <?php $__currentLoopData = $advertisement->suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="badge bg-secondary"><?php echo e($supplier->name); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <hr/>
                    </div>
                </div>
                <div class="col-12 col-md-4">
                    <div class="autoinfoRight">
                        <div class="autoinfoPrice"><?php echo e($advertisement->price . ' ' . $advertisement->currency); ?></div>
                        <div class="autoinfoUserBlock">
                            <div class="autoinfoUserBlockLeft">
                                <div class="autoinfoUserBlockLeftName"><?php echo e($advertisement->creator); ?></div>
                                <span class="autoinfoUserBlockLeftCountry"><?php echo e($advertisement->city); ?></span>
                                <span class="autoinfoUserBlockLeftCountry"><?php echo e($advertisement->creator_phone); ?></span>
                            </div>
                            <div class="autoinfoUserBlockRight">
                                <div class="autoinfoUserBlockIcon">
                                    <svg
                                        xmlns="http://www.w3.org/2000/svg"
                                        viewBox="0 0 448 512"
                                    >
                                        <path
                                            d="M224 256A128 128 0 1 0 224 0a128 128 0 1 0 0 256zm-45.7 48C79.8 304 0 383.8 0 482.3C0 498.7 13.3 512 29.7 512H418.3c16.4 0 29.7-13.3 29.7-29.7C448 383.8 368.2 304 269.7 304H178.3z"
                                        />
                                    </svg>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <?php $__env->startPush('other-css'); ?>
        
        <link rel="stylesheet" href="<?php echo e(asset('site-front/fancy/index.css')); ?>">

        <link
            rel="stylesheet"
            href="https://cdn.jsdelivr.net/npm/@fancyapps/ui@5.0/dist/fancybox/fancybox.css"
        />
        <link
            rel="stylesheet"
            href="https://cdn.jsdelivr.net/npm/@fancyapps/ui@5.0/dist/carousel/carousel.css"
        />
        <link
            rel="stylesheet"
            href="https://cdn.jsdelivr.net/npm/@fancyapps/ui@5.0/dist/carousel/carousel.thumbs.css"/>

        <script src="https://cdn.jsdelivr.net/npm/@fancyapps/ui@5.0/dist/carousel/carousel.thumbs.umd.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/@fancyapps/ui@5.0/dist/carousel/carousel.umd.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/@fancyapps/ui@5.0/dist/fancybox/fancybox.umd.js"></script>
        
    <?php $__env->stopPush(); ?>

    <?php $__env->startPush('other-js'); ?>
        <script>
            Fancybox.bind('[data-fancybox="gallery"]', {});

            const container = document.getElementById("myCarousel");
            const options = {
                axis: "x",
                Dots: false,
                Thumbs: {
                    type: "modern", // have classic type
                },
            };

            new Carousel(container, options, {
                Thumbs
            });
        </script>
    <?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.core.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\coders\php\advertisement\resources\views/site/detail.blade.php ENDPATH**/ ?>