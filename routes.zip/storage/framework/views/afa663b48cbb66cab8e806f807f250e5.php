<?php $__env->startSection('content'); ?>

    <div class="container-fluid">

        <div class="row">
            <div class="col-md-10">
                <h1 class="h3 mb-2 text-gray-800">Car's Models</h1>
            </div>

            <div class="col-md-2">
                <div class="row">
                    <div class="col-md-4">
                        <a href="<?php echo e(route('dashboard.car-model.index.trash')); ?>" class="btn btn-sm btn-warning">Trash</a>
                    </div>
                    <div class="col-md-4">
                        <a href="<?php echo e(route('dashboard.car-model.create')); ?>" class="btn btn-sm btn-info">Create</a>
                    </div>
                </div>
            </div>
        </div>



        <form action="" method="GET">
            <div class="row">
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="name">Name</label>
                        <input type="text" name="name" value="<?php echo e(request()->get('name')); ?>" id="name" class="form-control">
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="form-group">
                        <label for="creator">Creator</label>
                        <input type="text" name="creator" value="<?php echo e(request()->get('creator')); ?>" id="creator" class="form-control">
                    </div>
                </div>

                <div class="col-md-3">
                    <div style="visibility: hidden">a</div>
                    <button class="btn btn-sm btn-info" type="submit">
                        <i class="fa fa-magnifying-glass"></i>
                    </button>
                </div>
            </div>
        </form>

        <table class="table">
            <thead>
            <tr>
                <th>#</th>
                <th>Name</th>
                <th>Car</th>
                <th>Created By</th>
                <th>Created At</th>
                <th>Actions</th>
            </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->index + 1); ?></td>
                        <td><?php echo e($model->name); ?></td>
                        <td><?php echo e($model->car); ?></td>
                        <td><?php echo e($model->creator ?? ''); ?></td>
                        <td><?php echo e(date('d.m.Y H:i', strtotime($model->created_at))); ?></td>
                        <td>
                            <a class="btn btn-sm btn-primary" href="<?php echo e(route('dashboard.car-model.edit', $model->id)); ?>">
                                <i class="fa fa-pen"></i>
                            </a>
                            <a class="btn btn-sm btn-danger" href="<?php echo e(route('dashboard.car-model.delete', $model->id)); ?>">
                                <i class="fa fa-trash"></i>
                            </a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <?php echo e($models->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.core.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\coders\php\advertisement\resources\views/dashboard/car-model/index.blade.php ENDPATH**/ ?>