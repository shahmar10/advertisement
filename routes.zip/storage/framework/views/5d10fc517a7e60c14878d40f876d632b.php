<?php $__env->startSection('content'); ?>

    <div class="container-fluid">

        <div class="row">
            <div class="col-md-10">
                <h1 class="h3 mb-2 text-gray-800">Car Import</h1>
            </div>
        </div>

        <form action="<?php echo e(route('dashboard.car.import')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <div class="form-group">
                <input type="file" name="cars" class="form-control-file">
            </div>

            <button type="submit" class="btn btn-success">Import</button>
        </form>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.core.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\coders\php\advertisement\resources\views/dashboard/car/import.blade.php ENDPATH**/ ?>