</section>

<?php echo $__env->yieldPushContent('other-js'); ?>

</body>
</html>


<?php /**PATH C:\laragon\www\coders\php\advertisement\resources\views/site/core/foot.blade.php ENDPATH**/ ?>