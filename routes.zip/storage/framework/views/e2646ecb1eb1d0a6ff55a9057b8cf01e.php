<?php $__env->startSection('content'); ?>

    <div class="container-fluid">
        <h1 class="h3 mb-2 text-gray-800">Edit Car</h1>

        <form action="<?php echo e(route('dashboard.car.update', $car->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <div class="form-group">
                <label for="">Name</label>
                <input class="form-control" value="<?php echo e($car->name); ?>" type="text" name="name">
            </div>

            <button class="btn btn-sm btn-block btn-primary" type="submit">
                UPDATE
            </button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.core.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\coders\php\advertisement\resources\views/dashboard/car/edit.blade.php ENDPATH**/ ?>