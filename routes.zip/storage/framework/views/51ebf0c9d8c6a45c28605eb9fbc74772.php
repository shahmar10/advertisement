<section class="headerNav">
    <div class="headerLeft">
        <a href="index.html" class="turboLogo"> Turbo.az </a>
    </div>
    <div class="headerRight">
        <a href="/newauto.html" class="addNewAnnouncementBut">
            <svg
                xmlns="http://www.w3.org/2000/svg"
                width="25"
                height="25"
                viewBox="0 0 25 25"
            >
                <path
                    fill="#FFF"
                    fill-rule="nonzero"
                    d="M13.75 6.25h-2.5v5h-5v2.5h5v5h2.5v-5h5v-2.5h-5v-5zM12.5 0C5.625 0 0 5.625 0 12.5S5.625 25 12.5 25 25 19.375 25 12.5 19.375 0 12.5 0zm0 22.5c-5.5 0-10-4.5-10-10s4.5-10 10-10 10 4.5 10 10-4.5 10-10 10z"
                />
            </svg>

            <span>Yeni elan</span>
        </a>
    </div>
</section>
<?php /**PATH C:\laragon\www\coders\php\advertisement\resources\views/site/core/navbar.blade.php ENDPATH**/ ?>