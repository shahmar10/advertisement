<?php $__env->startSection('content'); ?>

    <div class="container-fluid">

        <div class="row">
            <div class="col-md-10">
                <h1 class="h3 mb-2 text-gray-800">Advertisements</h1>
            </div>
            <div class="col-md-2">
                <h1 class="h3 mb-2 text-gray-800">
                    <a href="<?php echo e(route('dashboard.export.index')); ?>" class="btn btn-sm btn-success">
                        <i class="fa fa-file-excel"></i> Excel
                    </a>
                </h1>
            </div>
        </div>
    
        <form action="" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <div class="form-group">
                <input type="file" class="form-control">
            </div>

            <button type="submit" class="btn btn-success">Import</button>
        </form>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.core.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\coders\php\advertisement\resources\views/dashboard/advertisement/import.blade.php ENDPATH**/ ?>