<table>
    <thead>
    <tr>
        <th>Id</th>
        <th>Body</th>
        <th>Creator</th>
        <th>Car</th>
        <th>Model</th>
        <th>Price</th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $advertisements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $advertisement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($advertisement->id); ?></td>
            <td><?php echo e($advertisement->body); ?></td>
            <td><?php echo e($advertisement->creator); ?></td>
            <td><?php echo e($advertisement->car); ?></td>
            <td><?php echo e($advertisement->model); ?></td>
            <td><?php echo e($advertisement->price); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH C:\laragon\www\coders\php\advertisement\resources\views/dashboard/export/advertisement.blade.php ENDPATH**/ ?>