<?php $__env->startSection('content'); ?>

    <div class="container-fluid">

        <div class="row">
            <div class="col-md-10">
                <h1 class="h3 mb-2 text-gray-800">Advertisements</h1>
            </div>
            <div class="col-md-2">
                <h1 class="h3 mb-2 text-gray-800">
                    <a href="<?php echo e(route('dashboard.export.index')); ?>" class="btn btn-sm btn-success">
                        <i class="fa fa-file-excel"></i> Excel
                    </a>
                </h1>
            </div>
        </div>

        <form action="" method="GET">
            <div class="row">
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="name">Name</label>
                        <input type="text" name="name" value="<?php echo e(request()->get('name')); ?>" id="name" class="form-control">
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="form-group">
                        <label for="creator">Creator</label>
                        <input type="text" name="creator" value="<?php echo e(request()->get('creator')); ?>" id="creator" class="form-control">
                    </div>
                </div>

                <div class="col-md-3">
                    <div style="visibility: hidden">a</div>
                    <button class="btn btn-sm btn-info" type="submit">
                        <i class="fa fa-magnifying-glass"></i>
                    </button>
                </div>
            </div>
        </form>

        <table class="table">
            <thead>
            <tr>
                <th>#</th>
                <th>Applier</th>
                <th>Car</th>
                <th>Model</th>
                <th>Price</th>
                <th>Created At</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $advertisements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $advertisement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->index + 1); ?></td>
                        <td><?php echo e($advertisement->creator); ?></td>
                        <td><?php echo e($advertisement->car); ?></td>
                        <td><?php echo e($advertisement->model); ?></td>
                        <td><?php echo e($advertisement->price); ?></td>
                        <td><?php echo e(date('d.m.Y H:i', strtotime($advertisement->created_at))); ?></td>
                        <td>
                            <span class="badge badge-pill badge-<?php echo e($advertisement->status_color); ?>"><?php echo e($advertisement->status_label); ?></span>
                        </td>
                        <td>
                            <a href="<?php echo e(route('dashboard.advertisement.show', $advertisement->id)); ?>" class="btn btn-sm btn-info">
                                <i class="fa fa-eye"></i>
                            </a>
                            <?php if($advertisement->status == 1): ?>
                                <a href="<?php echo e(route('dashboard.advertisement.approve', $advertisement->id)); ?>" class="btn btn-sm btn-success">
                                    <i class="fa fa-check"></i>
                                </a>
                                <a href="<?php echo e(route('dashboard.advertisement.reject', $advertisement->id)); ?>" class="btn btn-sm btn-danger">
                                    <i class="fa fa-x"></i>
                                </a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <?php echo e($advertisements->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.core.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\coders\php\advertisement\resources\views/dashboard/advertisement/index.blade.php ENDPATH**/ ?>