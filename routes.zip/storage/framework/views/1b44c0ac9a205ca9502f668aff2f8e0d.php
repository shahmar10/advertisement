
<div class="container-fluid">
    <?php if(session('fail')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('fail')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
</div>

<?php /**PATH C:\laragon\www\coders\php\advertisement\resources\views/dashboard/core/alert.blade.php ENDPATH**/ ?>