<?php $__env->startSection('content'); ?>

    <div class="container-fluid">
        <h1 class="h3 mb-2 text-gray-800">Create Car's Model</h1>

        <form action="<?php echo e(route('dashboard.car-model.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <div class="form-group">
                <label for="car_id">Car</label>
                <select name="car_id" id="car_id" class="form-control">
                    <option value="">Choose car</option>
                    <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($car->id); ?>"><?php echo e($car->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="form-group">
                <label for="">Name</label>
                <input class="form-control" type="text" name="name">
            </div>

            <button class="btn btn-sm btn-block btn-primary" type="submit">
                CREATE
            </button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.core.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\coders\php\advertisement\resources\views/dashboard/car-model/create.blade.php ENDPATH**/ ?>