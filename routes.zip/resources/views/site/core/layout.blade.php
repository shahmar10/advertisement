@include('site.core.head')
@include('site.core.header')
@include('site.core.navbar')

@yield('content')

@include('site.core.foot')
