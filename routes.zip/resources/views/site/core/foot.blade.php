</section>

@stack('other-js')

</body>
</html>


